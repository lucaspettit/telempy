import json


class Map:
  def __init__(self):
    pass

  def approx_map(self, packets: dict) -> [dict]:
    pass