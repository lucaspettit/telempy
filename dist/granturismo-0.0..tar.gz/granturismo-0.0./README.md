# TelemPy
Python library for retrieving Grand Truismo telemetry data from the Playstation console.
